from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional

from db import get_db
from apps.auth.oauth2 import get_current_user
from apps.rated_films import db_queries, schemas

router = APIRouter(prefix="/rated-films", tags=["rated_films"])

@router.post("/", response_model=schemas.RatedFilmOut)
def create_or_update_rating(
    data: schemas.RatedFilmCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Создаёт или обновляет оценку и статус просмотра фильма в рамках конкретного списка.

    - list_id: ID списка, в котором оцениваем фильм
    - movie_id: ID фильма, который принадлежит этому списку
    - rating_type: "stars" или "poors"
    - rating_value: 1..3
    - watched: True/False

    **Права**: владелец списка или гость с can_edit=True
    """
    return db_queries.create_or_update_rating(db, current_user.id, data)


@router.patch("/{rated_id}", response_model=schemas.RatedFilmOut)
def update_rating(
    rated_id: int,
    data: schemas.RatedFilmUpdate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Частично обновляет запись RatedFilm (rating_type, rating_value, watched).
    """
    return db_queries.update_rating(db, current_user.id, rated_id, data)


@router.delete("/{rated_id}", response_model=schemas.RatedFilmOut)
def delete_rating(
    rated_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Удаляет запись RatedFilm (сбрасывает оценку и статус просмотра).
    """
    return db_queries.delete_rating(db, current_user.id, rated_id)


@router.get("/", response_model=List[schemas.RatedFilmOut])
def get_user_ratings(
    watched: Optional[bool] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Получить список всех фильмов (RatedFilm), которые пользователь оценил
    (в любых списках).
    - Параметр watched=True/False фильтрует только просмотренные/непросмотренные.
    """
    rated_films = db_queries.get_user_ratings(db, current_user.id, watched)
    return rated_films
